from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def reviewer_dashboard():
    return render_template('Reviewer/reviewer_dashboard.html')


@app.route('/review_papers')
def review_papers():
    return render_template('Reviewer/review_papers.html')


@app.route('/revision_decisions')
def revision_decisions():
    return render_template('Reviewer/revision_decisions.html')


@app.route('/ensure_availability')
def ensure_availability():
    return render_template('Reviewer/ensure_availability.html')


@app.route('/track_submitted_articles')
def track_submitted_articles():
    return render_template('Reviewer/track_submitted_articles.html')


@app.route('/reviewer_send_complains')
def reviewer_send_complains():
    return render_template('Reviewer/reviewer_send_complains.html')


if __name__ == '__main__':
    app.run(debug=True)
