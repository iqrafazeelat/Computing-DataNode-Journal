from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def chief_editor_dashboard():
    return render_template('Chief Editor/chief_editor_dashboard.html')


@app.route('/manage_profile')
def manage_profile():
    return render_template('Chief Editor/manage_profile.html')


@app.route('/manage_payments')
def manage_payments():
    return render_template('Chief Editor/manage_payments.html')


@app.route('/manage_researchers')
def manage_researcher_articles():
    return render_template('Chief Editor/manage_researcher_articles.html')


@app.route('/check_editors_progress')
def check_editors_progress():
    return render_template('Chief Editor/check_editors_progress.html')


@app.route('/check_complains')
def check_complains():
    return render_template('Chief Editor/check_complains.html')


@app.route('/send_notification')
def send_notification():
    return render_template('Chief Editor/send_notification.html')


@app.route('/update_profile')
def update_profile():
    return render_template('Chief Editor/update_profile.html')


if __name__ == '__main__':
    app.run(debug=True)
