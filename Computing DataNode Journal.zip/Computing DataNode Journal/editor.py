from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def editor_dashboard():
    return render_template('Editor/editor_dashboard.html')


@app.route('/generate_report')
def generate_report():
    return render_template('Editor/generate_report.html')


@app.route('/manage_reviewers')
def manage_reviewers():
    return render_template('Editor/manage_reviewers.html')


@app.route('/decision_after_initial_screening')
def decision_after_initial_screening():
    return render_template('Editor/decision_after_initial_screening.html')


@app.route('/assign_paper_to_reviewers')
def assign_paper_to_reviewers():
    return render_template('Editor/assign_paper_to_reviewers.html')


@app.route('/editor_send_complains')
def editor_send_complains():
    return render_template('Editor/editor_send_complains.html')


@app.route('/editor_check_complains')
def editor_check_complains():
    return render_template('Editor/editor_check_complains.html')


@app.route('/editor_send_notification')
def editor_send_notification():
    return render_template('Editor/editor_send_notification.html')


@app.route('/view_all_articles')
def view_all_articles():
    return render_template('Editor/view_all_articles.html')


@app.route('/track_submitted_articles')
def track_submitted_articles():
    return render_template('Editor/track_submitted_articles.html')


@app.route('/send_papers_to_reviewers')
def send_papers_to_reviewers():
    return render_template('Editor/send_papers_to_reviewers.html')


@app.route('/send_papers_to_author')
def send_papers_to_author():
    return render_template('Editor/send_papers_to_author.html')


if __name__ == '__main__':
    app.run(debug=True)
